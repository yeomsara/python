import configparser
import pandas as pd
import os
import datetime as dt 


def load_s3_data(model_nm: "str") -> pd.DataFrame():    
    """
    load the split data at once
    
    # args
    - model_name: RETENTION, POTENTIAL, TIMING, PROD 
    """ 
    
    conf_dir = '/analytics/src/conf/config.ini'
    cfg = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
    cfg.read(conf_dir)
    DATA_DIR = cfg["Data"]["DATA_DIR"]
    
    # model name 
    model_nm = model_nm.upper()
    if model_nm not in ["RETENTION", "POTENTIAL", "TIMING", "PROD"]:
        print("check the model name.")
        return
    
    # make a date range
    now = dt.datetime.now().strftime("%Y%m%d")
    
    # extract file list
    file_list = [x for x in os.listdir(DATA_DIR) if (x.find(model_nm) > 0) and (x.find(now) > 0)]    
    if len(file_list) == 0:
        print("The files does not exist in input path.")
        return

    return_df = pd.DataFrame() # return table 뼈대    
    for file_name in file_list:
        if model_nm in file_name:
            temp_df = pd.read_parquet(os.path.join(DATA_DIR, file_name), engine='pyarrow')
            return_df = return_df.append(temp_df)
            del temp_df
            
    # 로드된 파일 옮기는 것 구현 & 테스트 필요
    
    return return_df