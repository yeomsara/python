import warnings
warnings.filterwarnings('ignore')

import os
import pandas as pd
import datetime as dt
from datetime import timedelta
import configparser
from functools import wraps


class data_management():
    """
    # 데이터 관련 전반적인 클래스
    """
    root_dir = '/analytics/LDCC/src/'
    #root_dir = 'C:/Users/LDCC/Desktop/mdap/code/myCode/개발환경/testdata/'
    conf_dir = os.path.join(root_dir, 'conf/test.ini')
    
    # init
    def __init__(self, model_nm, work_date):
        self.model_nm = model_nm.upper()
        self.work_date = work_date
        self.this_day = str(dt.date.today().strftime("%Y%m%d")) # today를 어떻게 써야해
        self.this_month = int(self.this_day[0:6])
        
        # management option
        self.PRESERVE_DURATION = 2
        
        # config
        cfg = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
        cfg.read(self.conf_dir)
        self.INPUT_DIR = cfg["Data"]["DATA_DIR"] 
        self.OUTPUT_DIR = cfg["Data"]["OUTPUTDATA_DIR"] 
        self.PRE_INPUT_DIR = cfg["Data"]["PRE_INPUT_DIR"] 
        self.PRE_OUTPUT_DIR = cfg["Data"]["PRE_OUTPUT_DIR"] 
        
#         self.INPUT_DIR = os.path.join(self.root_dir, 'input/')
#         self.OUTPUT_DIR = os.path.join(self.root_dir, 'output/')
#         self.PRE_INPUT_DIR = os.path.join(self.root_dir, 'pre_input/')
#         self.PRE_OUTPUT_DIR = os.path.join(self.root_dir, 'pre_output/')
        
    def check_model_nm(func):
        """
        decorator: check model name
        # made by: KHR
        # arg
            - x
        # return: df
        """
        # @wraps(func)
        def wrapper(self):            
            if self.model_nm not in ["RETENTION", "POTENTIAL", "TIMING", "RECOM"] or not self.model_nm:
                print("check the model name.")
                return
            return func(self)
        return wrapper
            
    def check_target_date(func):
        """
        check target date according by model name
        # made by: KHR
        # args
        - model_name: RETENTION, POTENTIAL, TIMING, RECMD
        - target_date: %Y-%m-%d ex.2022-04-01    
        # return: str
        """ 
        # @wraps(func)
        def wrapper(self):
            today = dt.date.today()
            
            # 모델별 temp_target_date 생성
            if self.model_nm == "RETENTION" or self.model_nm == "POTENTIAL": # 월배치
                temp_target_date = dt.datetime.now().strftime("%Y%m") +"01"
            elif self.model_nm == "TIMING": # 주배치, 매주 바로 직전 일요일
                temp_target_date = today - dt.timedelta((today.weekday() + 1) % 7)
                temp_target_date = temp_target_date.strftime("%Y%m%d")
            else: # 일배치, 그러나 target date는 실행일자의 하루 전날
                temp_target_date = today - dt.timedelta(1)
                temp_target_date = temp_target_date.strftime("%Y%m%d")
                
            # decide target date depending on self.model_nm
            # target_date가 빈 문자열이면 생성해둔 temp_target_date가 target_date가 됨
            if not self.work_date:
                self.work_date = temp_target_date
            else: # 빈문자열 아님
                if '-' in self.work_date:
                    self.work_date = self.work_date.replace('-', '')
                if not self.work_date.isdigit() or self.work_date != temp_target_date:
                    self.work_date = temp_target_date
                else:
                    self.work_date = temp_target_date
            return func(self)
        return wrapper
    
    @check_model_nm
    @check_target_date
    def data_load(self) -> pd.DataFrame():
        """
        load the split data and combine at once        
        # made by: KHR
        # arg
            - x
        # return: df
        """
        
        file_list = [x for x in os.listdir(self.INPUT_DIR) if (x.find(self.model_nm) > 0) and (x.find(self.work_date) > 0)]
        if len(file_list) == 0:
            print("The files does not exist in input path.")
            return
        
        return_df = pd.DataFrame()
        for file in file_list:
            if self.model_nm in file:
                temp_df = pd.read_parquet(os.path.join(self.INPUT_DIR, file), engine = 'pyarrow')
                return_df = return_df.append(temp_df)
                del temp_df
        return return_df
    
    def move_data(self):
        """
        move input
        move output data and remove chk file (except files with working date)        
        # made by: soonwon
        # arg
            - x
        # return: x
        """
        
        # input dataset move
        inputdata_dir_list = [x for x in os.listdir(self.INPUT_DIR) if x.find(self.model_nm) > 0]        
        for file in inputdata_dir_list:
            os.replace(
                os.path.join(self.INPUT_DIR, file),
                os.path.join(self.PRE_INPUT_DIR, file)
            )
        
        # output dataset move & chk remove        
        outputdata_dir_list = [x for x in os.listdir(self.OUTPUT_DIR) if x.find(self.model_nm) > 0]
        for file in outputdata_dir_list:
            if (file.find(".chk") > 0) and (file.find(self.work_date) < 0): # 당일 chk 파일 아닌 경우
                os.remove(
                    os.path.join(self.OUTPUT_DIR, file),
                )
            if (file.find(".csv") > 0) and (file.find(self.work_date) < 0): # 당일 csv 파일 아닌 경우
                os.replace(
                    os.path.join(self.OUTPUT_DIR, file),
                    os.path.join(self.PRE_OUTPUT_DIR, file)
                )
        
    def remove_data(self):
        """
        remove input, output data that has expired storage preriods.
        # made by: soonwon
        # arg
            - x
        # return: x
        """
        
        # remove input dataset
        pre_inputdataset = [x for x in os.listdir(self.PRE_INPUT_DIR) if ((self.this_month - int(x.split(".")[0].split("_")[-1][0:6])) > self.PRESERVE_DURATION) and \
                            (x.find(self.model_nm) > 0)]
        for file in pre_inputdataset:
            os.remove(
                os.path.join(self.PRE_INPUT_DIR, file)
            )
        
        # remove output dataset
        pre_outputdataset = [x for x in os.listdir(self.PRE_OUTPUT_DIR) if ((self.this_month - int(x.split("_")[-1][0:6])) > self.PRESERVE_DURATION) and \
                             (x.find(self.model_nm) > 0)]
        for file in pre_outputdataset:
            os.remove(
                os.path.join(self.PRE_OUTPUT_DIR, file)
            )