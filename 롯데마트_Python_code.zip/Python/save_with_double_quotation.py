import os
import pandas as pd
from datetime import datetime

def save_with_double_quotation(sPath: str,
                               fName: str,
                               fTable: pd.DataFrame):    
    """
    # 테이블 크기가 클 것 같아 복사 없이 바로 처리 진행
    # args
     - sPath: 파일저장 주소
     - fNmae: 저장될 파일 이름
     - fTable: 저장되는 판다스 테이블
    """
    col = fTable.columns
    for idx in col:
        fTable.loc[:, idx] = fTable[idx].apply(lambda x: "\"" + str(x) + "\"")
    file_name = "/" + fName + "_" + datetime.today().strftime("%y%m%d") + ".csv"
    fTable.to_csv(os.path.join(sPath, file_name),
                  index = False,
                  encoding = "utf-8-sig")