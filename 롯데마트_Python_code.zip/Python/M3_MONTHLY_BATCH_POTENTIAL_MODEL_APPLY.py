#----------------------------------------------------------
# ■ List of Package
# 예측에사용되는 패키지 리스트 아래에 추가
#----------------------------------------------------------
import pickle,ast,joblib
import pandas as pd
import numpy as np
from sklearn.metrics import confusion_matrix, classification_report
import lightgbm as lgbm
from sklearn.preprocessing import Binarizer
import os


import configparser
#conf_dir = '/analytics/src/conf/config.ini'
conf_dir = '/analytics/mdap/src/conf/config.ini'
cfg = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
cfg.read(conf_dir)
import sys 
#sys.path.append('/analytics/codeshare/')
sys.path.append('/analytics/mdap/src/codeshare/')
# import read_split_data as read_parquet
#---------------------------------------------------------
# ■ setting configuration (db_connectionm, load_model)
#---------------------------------------------------------

#Potential
global MODEL_DIR,M1_MODEL_NAME,M2_MODEL_NAME,M3_MODEL_NAME,SCALER_NAME
MODEL_DIR     = cfg['Potential']['MODEL_DIR']
M1_MODEL_NAME = cfg['Potential']['M1_MODEL_NAME']
M2_MODEL_NAME = cfg['Potential']['M2_MODEL_NAME']
M3_MODEL_NAME = cfg['Potential']['M3_MODEL_NAME']
M1_THRESHOLD = cfg['Potential']['M1_THRESHOLD']
M2_THRESHOLD = cfg['Potential']['M2_THRESHOLD']
M3_THRESHOLD = cfg['Potential']['M3_THRESHOLD']

import sys
sys.path.append('/analytics/mdap/src/codeshare/')
import redshift_dbconnect as rs_connect
import data_management as dm
import datetime
import argparse

parser = argparse.ArgumentParser(description = 'Potential System ')
parser.add_argument('--target_date', help = '분석 기준일')
args = parser.parse_args()

try : 
    target_date = args.target_date
except : 
    target_date = None
    
# # Target-date setting     
# if (target_date == None) | (target_date == 'None') :
#     start_time  = datetime.datetime.now().strftime('%Y-%m-%d')    
# print(target_date)
# format = '%Y-%m-%d'
# output_date = datetime.datetime.strptime(target_date,format)
# output_date=output_date.strftime('%Y%m%d')    


def NULL_PROCESS(df):
    #고객등급-마트
#     df.CUST_GRD_MART_FG_CD.fillna('04',inplace=True) 
    #구매 주기
    df.PRCHS_CYCLE.fillna(183.0,inplace=True) 
    #구매 주기 변동성
    df.PRCHS_CYCLE_VAR.fillna(10.0,inplace=True) 
    #구매 대분류수 변동성
    df.PRCHS_L1_CNT_VAR.fillna(10.0,inplace=True) 
    #구매 중분류수 변동성
    df.PRCHS_L2_CNT_VAR.fillna(10.0,inplace=True) 
    #구매 SKU수 변동성
    df.PRCHS_SKU_CNT_VAR.fillna(10.0,inplace=True) 
    #구매 금액 변동성
    df.PRCHS_AMT_VAR.fillna(10.0,inplace=True) 
    #구매 금액 변동성 지수
    df.PRCHS_AMT_VAR_IDEX.fillna(5.0,inplace=True)
    #행사유형선호도
    df.EVNT_PRF_UNITY.fillna(0,inplace=True)
    #Calendar 통합 선호도
    df.CLDR_SNSTIVE_UNITY.fillna(0,inplace=True)
    #주거래점 Top1 거리
    df.MAIN_PRCHS_STR_TOP1_DSTNC.fillna(1850.0,inplace=True)
    #부문별 RFMP 변화량
    df.RFMP_GRADE_2M_DIFF_SCT1.fillna(df.RFMP_GRD_SCT1,inplace=True)
    df.RFMP_GRADE_1M_DIFF_SCT3.fillna(df.RFMP_GRD_SCT3,inplace=True)
    df.RFMP_GRADE_2M_DIFF_SCT3.fillna(df.RFMP_GRD_SCT3,inplace=True)
    #RFMP 변화량
    df.RFMP_GRADE_1M_DIFF.fillna(df.RFMP_GRD,inplace=True)
    df.RFMP_GRADE_2M_DIFF.fillna(df.RFMP_GRD,inplace=True) 
    #구매주기 변화량
    df.PRCHS_CYCLE_1M_DIFF.fillna(df.PRCHS_CYCLE,inplace=True) 
    df.PRCHS_CYCLE_2M_DIFF.fillna(df.PRCHS_CYCLE,inplace=True)
    #EC 온라인(1년)
    df.LTON_ONLN_PUR_NTM.fillna(0,inplace=True)
    df.MRT_ONLN_SL_AMT.fillna(0,inplace=True)
    df.MRT_ONLN_PUR_NTM.fillna(0,inplace=True)
    df.ALL_ONLN_SL_AMT.fillna(0,inplace=True)
    #부문별 구매 금액/횟수 변화량
    df.PRCHS_AMT_4M_DIFF_SCT1.fillna(df.PRCHS_AMT_1M_SCT1,inplace=True) 
    df.PRCHS_AMT_3M_DIFF_SCT2.fillna(df.PRCHS_AMT_1M_SCT2,inplace=True)
    df.PRCHS_AMT_4M_DIFF_SCT2.fillna(df.PRCHS_AMT_1M_SCT2,inplace=True) 
    df.PRCHS_AMT_5M_DIFF_SCT2.fillna(df.PRCHS_AMT_1M_SCT2,inplace=True) 
    df.PRCHS_CNT_4M_DIFF_SCT2.fillna(df.PRCHS_CNT_1M_SCT2,inplace=True) 
    df.PRCHS_AMT_4M_DIFF_SCT3.fillna(df.PRCHS_AMT_1M_SCT3,inplace=True) 
    df.PRCHS_CNT_5M_DIFF_SCT3.fillna(df.PRCHS_CNT_1M_SCT3,inplace=True)
    
    return df.copy()

#get dummi
#minmax scaling
from pickle import load

def PREPROCESSING(df):
    input_df = df.copy()
    
    #제외 고객 filtering을 위함.
    input_df.PRCHS_CNT_1M.fillna(0,inplace=True)
    input_df.PRCHS_CNT_3M.fillna(0,inplace=True)
    
    df_1=input_df[(input_df["PRCHS_CNT_1M"]>=2) | (input_df["PRCHS_CNT_3M"]>=3)]
    
    #제외고객
    df_filter=input_df[(input_df["PRCHS_CNT_1M"]<2) & (input_df["PRCHS_CNT_3M"]<3)]
    
    df_1.loc[df_1['CUST_ANAL_GRP']=='P2','CUST_ANAL_GRP_P2'] = 1
    df_1.CUST_ANAL_GRP_P2.fillna(0,inplace=True) 
    
    #변경할 것!
    df_1.loc[df_1['CUST_GRD_MART_FG_CD']=='01','CUST_GRD_MART_FG_CD_01'] = 1
    df_1.CUST_GRD_MART_FG_CD_01.fillna(0,inplace=True) 

    tg_feature = ['ANL_DT','INTG_CUST_NO','CUST_ANAL_GRP']
    drop_feature = ['ANL_DT','INTG_CUST_NO','CUST_GRD_MART_FG_CD','CUST_ANAL_GRP']
    
    model_feature=list(df_1.columns.difference(drop_feature))
   
    # 설명변수
    X = df_1[model_feature] 
    
    # 타겟변수
    Y = df_1[tg_feature] 
    
    # 제외고객 타겟변수
    Y_filter = df_filter[tg_feature] 
    
    return X.copy(),Y.copy(),Y_filter.copy()

def SPLIT_TARGET(df,target):
    split_df = df.copy()
    
    if target == 'TARGET_1M':
        FNL_feature = ['CLDR_SNSTIVE_UNITY',
                     'MAIN_PRCHS_STR_TOP1_DSTNC',
                     'OFF_PRCHS_AMT_1M_DIFF',
                     'OFF_PRCHS_AMT_4M_DIFF',
                     'OFF_PRCHS_AMT_5M_DIFF',
                     'PRCHS_AMT',
                     'PRCHS_AMT_1M_DIFF',
                     'PRCHS_AMT_2M_DIFF',
                     'PRCHS_AMT_3M',
                     'PRCHS_AMT_4M_DIFF',
                     'PRCHS_AMT_5M_DIFF',
                     'PRCHS_AMT_5M_DIFF_SCT2',
                     'PRCHS_AMT_VAR_IDEX',
                     'PRCHS_CNT',
                     'PRCHS_CNT_3M',
                     'PRCHS_CNT_3M_DIFF',
                     'PRCHS_CNT_5M_DIFF',
                     'PRCHS_CNT_5M_DIFF_SCT3',
                     'PRCHS_CYCLE',
                     'PRCHS_CYCLE_1M_DIFF',
                     'PRCHS_CYCLE_2M_DIFF',
                     'PRCHS_L1_CNT_VAR',
                     'PRCHS_LAPSE',
                     'PRCHS_PER_AVG_AMT',
                     'PRCHS_SKU_CNT_VAR',
                     'RFMP_GRADE_1M_DIFF',
                     'RFMP_GRADE_1M_DIFF_SCT3',
                     'RFMP_GRADE_2M_DIFF',
                     'RFMP_GRD',
                     'RFMP_GRD_SCT2',
                     'RFMP_GRD_SCT3',
                     'RFMP_PRFT',
                     'RFMP_RECENCY',
                     'TOT_PNT']

        
    elif target == 'TARGET_2M':
        FNL_feature = ['ALL_ONLN_SL_AMT',
                     'CLDR_SNSTIVE_UNITY',
                     'MAIN_PRCHS_STR_TOP1_DSTNC',
                     'MRT_ONLN_SL_AMT',
                     'OFF_AVG_AMT_6M',
                     'OFF_PRCHS_AMT_1M_DIFF',
                     'OFF_PRCHS_AMT_2M_DIFF',
                     'OFF_PRCHS_AMT_4M_DIFF',
                     'OFF_PRCHS_AMT_5M_DIFF',
                     'PRCHS_AMT',
                     'PRCHS_AMT_1M',
                     'PRCHS_AMT_1M_DIFF',
                     'PRCHS_AMT_2M',
                     'PRCHS_AMT_3M',
                     'PRCHS_AMT_3M_DIFF',
                     'PRCHS_AMT_4M_DIFF',
                     'PRCHS_AMT_4M_DIFF_SCT1',
                     'PRCHS_AMT_4M_DIFF_SCT2',
                     'PRCHS_AMT_4M_DIFF_SCT3',
                     'PRCHS_AMT_5M_DIFF',
                     'PRCHS_CNT',
                     'PRCHS_CNT_1M',
                     'PRCHS_CNT_2M',
                     'PRCHS_CNT_3M',
                     'PRCHS_CNT_3M_DIFF',
                     'PRCHS_CNT_4M_DIFF',
                     'PRCHS_CNT_4M_DIFF_SCT2',
                     'PRCHS_CNT_5M_DIFF',
                     'PRCHS_CYCLE',
                     'PRCHS_CYCLE_2M_DIFF',
                     'PRCHS_CYCLE_VAR',
                     'PRCHS_L1_CNT_VAR',
                     'PRCHS_L2_CNT_VAR',
                     'PRCHS_LAPSE',
                     'PRCHS_PER_AVG_AMT',
                     'PRCHS_SKU_CNT_VAR',
                     'RFMP_GRADE_1M_DIFF',
                     'RFMP_GRADE_2M_DIFF',
                     'RFMP_GRADE_2M_DIFF_SCT1',
                     'RFMP_GRADE_2M_DIFF_SCT3',
                     'RFMP_GRD',
                     'RFMP_GRD_SCT3',
                     'RFMP_PRFT',
                     'TOT_PNT',
                     'CUST_ANAL_GRP_P2']   
        
    elif target == 'TARGET_3M':
        FNL_feature = ['ALL_ONLN_SL_AMT',
                     'CLDR_SNSTIVE_UNITY',
                     'EVNT_PRF_UNITY',
                     'LTON_ONLN_PUR_NTM',
                     'MAIN_PRCHS_STR_TOP1_DSTNC',
                     'MRT_ONLN_PUR_NTM',
                     'MRT_ONLN_SL_AMT',
                     'OFF_AVG_AMT_6M',
                     'OFF_PRCHS_AMT_1M',
                     'OFF_PRCHS_AMT_3M_DIFF',
                     'OFF_PRCHS_AMT_5M_DIFF',
                     'OFF_PRCHS_AMT_6M',
                     'OFF_PRCHS_CNT_4M_DIFF',
                     'OFF_PRCHS_CNT_5M_DIFF',
                     'PRCHS_AMT',
                     'PRCHS_AMT_1M',
                     'PRCHS_AMT_1M_DIFF',
                     'PRCHS_AMT_2M',
                     'PRCHS_AMT_3M',
                     'PRCHS_AMT_3M_DIFF',
                     'PRCHS_AMT_3M_DIFF_SCT2',
                     'PRCHS_AMT_4M_DIFF',
                     'PRCHS_AMT_5M_DIFF',
                     'PRCHS_AMT_VAR',
                     'PRCHS_CNT',
                     'PRCHS_CNT_3M',
                     'PRCHS_CNT_3M_DIFF',
                     'PRCHS_CNT_4M_DIFF',
                     'PRCHS_CYCLE',
                     'PRCHS_CYCLE_2M_DIFF',
                     'PRCHS_CYCLE_VAR',
                     'PRCHS_LAPSE',
                     'PRCHS_PER_AVG_AMT',
                     'RFMP_GRADE_1M_DIFF',
                     'RFMP_GRADE_1M_DIFF_SCT3',
                     'RFMP_GRADE_2M_DIFF',
                     'RFMP_GRADE_2M_DIFF_SCT3',
                     'RFMP_GRD',
                     'RFMP_GRD_SCT2',
                     'RFMP_GRD_SCT3',
                     'RFMP_PRFT',
                     'TOT_PNT',
                     'CUST_GRD_MART_FG_CD_01']         
    return split_df[FNL_feature].copy()

def PREDICT(df,model_dir,model_name,model_threshold):
    df_model = df.copy()
    #모델 load
    model = load_model(model_dir,model_name)
    #모델 FEATURE 순 정렬
    feature_col = model.feature_name_
    df_model = df_model[feature_col]
    #target predict score
    pred_y_prob = model.predict_proba(df_model)
    pred_proba = pred_y_prob[:,1].reshape(-1,1)
    #threshold
    binarizer = Binarizer(threshold=model_threshold).fit(pred_proba) 
    #target predict
    pred_y_target = binarizer.transform(pred_proba)
    return pred_y_target,pred_proba


#----------------------------------------------------------
# ■ List of definition
#----------------------------------------------------------

#모델로드시 아래 save model로 joblib패키지 이용해서 pickle파일로 저장한경우 load_model 패키지 사용하여 로드

def load_model(DIR,MODEL_NAME):
    model_dir  = DIR+MODEL_NAME
    load_model = joblib.load(model_dir)
    return load_model

def save_model(clf,mdl_file_nm):
    DIR = MODEL_DIR
    model_name = mdl_file_nm
    model = joblib.dump(clf,open(DIR+model_name+".pkl",'wb'))
    model_dir = DIR+model_name
    print('%s 경로에 %s 모델 저장완료 '%(DIR,model_name+".pkl"))
    return model_name



#----------------------------------------------------------
# ■ predict pipeline
#----------------------------------------------------------
try:
    with open(f'{HOME_DIR}/logs/mdap_model/{model_name}_SUCCESS_{today_date}.log', "a") as file:
        file.write('====================================================================================================\n')
        file.write(f'Log Type   : [ Success ]\n')
        file.write(f'Program ID : [ {module_name} ]\n')
        file.write(f'Model ID   : [ {model_id} ]\n')
        file.write(f'Start Time : [ {start_time} ]\n')
        file.write(f'Parameter  : [ {target_date} ]\n')
        file.write('====================================================================================================\n')
        a = '**********    Potential Python Program Start    **********'
        file.write(a.center(100, ' '))
        file.write('\n====================================================================================================\n')
        file.write('+---------+---------+---------+---------+---------+---------+---------+---------+---------+---------+\n')
        file.close()
        
    #Step1 - Load Data 
    logger_success.error('*** (Step1) - Load Data Start')
    cl = dm.data_management("POTENTIAL", target_date)
    df = cl.data_load()
    #output_file = '/analytics/src/data/output/F_ANL_POTENTIAL_VIP_PRED_RESULT_' + output_date
    output_file = '/analytics/mdap/src/data/output/F_ANL_POTENTIAL_VIP_PRED_RESULT_' + target_date
    
    #Column명 대문자 변환
    new_columns = []
    for i in list(df.columns):
        new_columns.append(i.upper())
    df.columns = new_columns
    
    #FEATURE TYPE 변환
    float_list=list(df.columns)
    float_list.remove('ANL_DT')
    float_list.remove('INTG_CUST_NO')
    float_list.remove('CUST_GRD_MART_FG_CD')
    float_list.remove('CUST_ANAL_GRP')
    for i in float_list:
        df[i] = df[i].astype(float)
    
    #Step2 - preprocessing 
    logger_success.error('*** (Step2) - Preprocessing Start')

    #Step2_1 - Filter
    X,Y,Y_F=PREPROCESSING(df)
    X.CUST_ANAL_GRP_P2 = X.CUST_ANAL_GRP_P2.astype('category')
    X.CUST_GRD_MART_FG_CD_01 = X.CUST_GRD_MART_FG_CD_01.astype('category')

    #Step2_2 - Null    
    X_1 = NULL_PROCESS(X)

    #Step2_3 - Target Split
    X_M1=SPLIT_TARGET(X_1,"TARGET_1M")
    X_M2=SPLIT_TARGET(X_1,"TARGET_2M")
    X_M3=SPLIT_TARGET(X_1,"TARGET_3M")
    

    #Step3 - Predict
    logger_success.error('*** (Step3) - Predict Start')

    m1_target, m1_score = PREDICT(X_M1,MODEL_DIR,M1_MODEL_NAME,float(M1_THRESHOLD)) 
    m2_target, m2_score = PREDICT(X_M2,MODEL_DIR,M2_MODEL_NAME,float(M2_THRESHOLD))
    m3_target, m3_score = PREDICT(X_M3,MODEL_DIR,M3_MODEL_NAME,float(M3_THRESHOLD))
    
    
    #Step4 - Result Table 
    logger_success.error('*** (Step4) - Result Table Start')

    Y.loc[:,"ANL_DT"] = datetime.datetime.strptime(target_date, '%Y%m%d').strftime('%Y-%m-%d')
    Y.loc[:,"M1_PREDICT_PROB"] = np.round(m1_score,2)[:,0]
    Y.loc[:,"M2_PREDICT_PROB"] = np.round(m2_score,2)[:,0]
    Y.loc[:,"M3_PREDICT_PROB"] = np.round(m3_score,2)[:,0]
    Y.loc[:,"M1_TARGET_CLASS"] = m1_target[:,0].astype('int').astype('str')
    Y.loc[:,"M2_TARGET_CLASS"] = m2_target[:,0].astype('int').astype('str')
    Y.loc[:,"M3_TARGET_CLASS"] = m3_target[:,0].astype('int').astype('str')
    
    Y_F.loc[:,"ANL_DT"] = datetime.datetime.strptime(target_date, '%Y%m%d').strftime('%Y-%m-%d')
    Y_F.loc[:,"M1_PREDICT_PROB"] = 0
    Y_F.loc[:,"M2_PREDICT_PROB"] = 0
    Y_F.loc[:,"M3_PREDICT_PROB"] = 0
    Y_F.loc[:,"M1_TARGET_CLASS"] = '0'
    Y_F.loc[:,"M2_TARGET_CLASS"] = '0'
    Y_F.loc[:,"M3_TARGET_CLASS"] = '0'
    
    Y_concat = pd.concat([Y, Y_F],axis=0)
    
    output = Y_concat[['ANL_DT','INTG_CUST_NO','CUST_ANAL_GRP','M1_PREDICT_PROB','M2_PREDICT_PROB','M3_PREDICT_PROB','M1_TARGET_CLASS','M2_TARGET_CLASS','M3_TARGET_CLASS']].copy()
    output["INTG_CUST_NO"] = output["INTG_CUST_NO"].astype('str').str.zfill(14)
    output = output.rename(columns={'CUST_ANAL_GRP':'CUST_GRADE'})
    
    if os.path.isfile(output_file+'.csv'):
        os.remove(output_file+'.csv')
        os.remove(output_file+'.chk')        
    
    output.to_csv(output_file+'.csv', index=False)
    open(output_file+'.chk', mode='w').close()

    cl.move_data()
    cl.remove_data()
    
    end_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with open(f'{HOME_DIR}/logs/mdap_model/{model_name}_SUCCESS_{today_date}.log', "a") as file:
        file.write('+---------+---------+---------+---------+---------+---------+---------+---------+---------+---------+\n')
        file.write('====================================================================================================\n')
        file.write(f'End Time : [ {end_time} ]\n')
        a = '**********    Potential Python Program End    **********'
        file.write(a.center(100, ' '))
        file.write('\n====================================================================================================\n')
        file.close()
    
except Exception as e : 
    logger_fail     = logging.getLogger('fail_log')
    fh_fail = logging.FileHandler(f'{HOME_DIR}/logs/mdap_model/{model_name}_FAIL_{today_date}.log')
    formatter_fail = logging.Formatter(f'[ %(asctime)s ][ LineNo. : %(message)s')
    fh_fail.setFormatter(formatter_fail)
    logger_fail.addHandler(fh_fail)    
    with open(f'{HOME_DIR}/logs/mdap_model/{model_name}_FAIL_{today_date}.log', "a") as file:
        file.write('====================================================================================================\n')
        file.write(f'Log Type   : [ Error ]\n')
        file.write(f'Program ID : [ {module_name} ]\n')
        file.write(f'Model ID   : [ {model_id} ]\n')
        file.write(f'Start Time : [ {start_time} ]\n')
        file.write(f'Parameter  : [ {target_date} ]\n')
        file.write('====================================================================================================\n')
        a = '**********    Potential Python Program Error    **********'
        file.write(a.center(100, ' '))
        file.write('\n====================================================================================================\n')
        file.write('+---------+---------+---------+---------+---------+---------+---------+---------+---------+---------+\n')
        file.close()
        
    _, _, exc_traceback = sys.exc_info()
    logger_fail.error(f'{exc_traceback.tb_lineno} ] ※ Error : {e}')  
    
    end_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with open(f'{HOME_DIR}/logs/mdap_model/{model_name}_FAIL_{today_date}.log', "a") as file:
        file.write('+---------+---------+---------+---------+---------+---------+---------+---------+---------+---------+\n')
        file.write('====================================================================================================\n')
        file.write('End Time : [ {end_time} ]\n')
        a = '**********    Potential Python Program Error    **********'
        file.write(a.center(100, ' '))
        file.write('\n====================================================================================================\n')
        file.close() 
