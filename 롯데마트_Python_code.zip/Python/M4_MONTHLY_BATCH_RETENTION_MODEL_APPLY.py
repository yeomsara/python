#----------------------------------------------------------
# ■ List of Package
#----------------------------------------------------------
## 함수 로딩  
import pandas as pd
import numpy as np

import time 
import argparse
import datetime
from datetime import timedelta

import warnings
import logging 
import pickle
import subprocess
import numexpr as ne
import psutil
import shutil

## 후처리 모듈
import re
import os
from functools import reduce
from tqdm.notebook import tqdm
import pickle,ast,joblib

import configparser
conf_dir = '/analytics/mdap/src/conf/config.ini'
cfg = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
cfg.read(conf_dir)

import sys 
sys.path.append('/analytics/mdap/src/codeshare/')
import redshift_dbconnect as rs_connect
import data_management  as dm

#---------------------------------------------------------
# ■ Setting Configuration 
#---------------------------------------------------------
# Retention
global MODEL_DIR,P_MODEL_NAME,G_MODEL_NAME,P_THRESHOLD,G_THRESHOLD, HOME_DIR, LOG_CONFIG
MODEL_DIR    = cfg['Retention']['MODEL_DIR']
P_MODEL_NAME = cfg['Retention']['P_MODEL_NAME']
G_MODEL_NAME = cfg['Retention']['G_MODEL_NAME']
P_THRESHOLD = cfg['Retention']['P_THRESHOLD']
G_THRESHOLD = cfg['Retention']['G_THRESHOLD']

HOME_DIR   = cfg['common']['home_dir']
LOG_CONFIG = cfg['common']['log_config']
#----------------------------------------------------------
# ■ logging
#----------------------------------------------------------
import logging
import logging.config
import traceback


today_date = datetime.datetime.now().strftime('%Y%m%d')
start_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
module_name = 'M4_MONTHLY_BATCH_RETENTION_MODEL_APPLY.py'
model_name = 'M4_MONTHLY_BATCH_RETENTION_MODEL_APPLY'
model_id = 'RETENTION'

logger_success     = logging.getLogger('success_log')
fh_success = logging.FileHandler(f'{HOME_DIR}/logs/mdap_model/{model_name}_SUCCESS_{today_date}.log')
formatter_success = logging.Formatter(f'[ %(asctime)s ][ LineNo. : %(lineno)d ] %(message)s')
fh_success.setFormatter(formatter_success)
logger_success.addHandler(fh_success)

parser = argparse.ArgumentParser(description = 'Retention System ')
parser.add_argument('--target_date', help = '분석 기준일')
args = parser.parse_args()

try : 
    target_date = args.target_date
except : 
    target_date = None
 
    
def split_vip_normal(df): 
    
    # 우수고객 변수 리스트
    vip_col = [
        'INTG_CUST_NO','CUST_ANAL_GRP',
        'APT_YN_H','AGE_GRP_03',
        'PRCHS_CNT','PRCHS_AMT',
        'RFMP_GRD','RFMP_RECENCY',
        'RFMP_FREQUENCY','PRCHS_CYCLE', 
        'PRCHS_CYCLE_VAR','PRCHS_LAPSE',
        'RFMP_GRADE_2M_CHG','PRCHS_CYCLE_2M_DIFF',
        'PRCHS_AMT_2M_CHG','PRCHS_AMT_3M_CHG',
        'PRCHS_CNT_2M_CHG','PRCHS_CNT_4M_CHG',
        'PRCHS_CNT_1M','PRCHS_CNT_2M',
        'PRCHS_CNT_3M','CLDR_SNSTIVE_UNITY',
        'MAIN_PRCHS_STR_TOP1_DSTNC','ON_PRCHS_CNT_6M',
        'OFF_PRCHS_CNT_6M','TOT_PNT',
        'OFF_PRCHS_AMT_2M_CHG','OFF_PRCHS_AMT_4M_CHG'
         ]
    
    # 일반고객 변수 리스트
    normal_col = [
        'INTG_CUST_NO','CUST_ANAL_GRP',
        'PRCHS_CNT', 'RFMP_RECENCY',
        'RFMP_FREQUENCY', 'PRCHS_CYCLE',
        'PRCHS_CYCLE_VAR', 'PRCHS_L2_CNT_VAR',
        'PRCHS_AMT_VAR_IDEX', 'PRCHS_LAPSE',
        'RFMP_GRADE_2M_CHG', 'PRCHS_AMT_1M',
        'PRCHS_AMT_2M', 'PRCHS_CNT_1M', 
        'PRCHS_CNT_2M', 'PRCHS_CNT_3M',
        'CLDR_SNSTIVE_UNITY', 'MAIN_PRCHS_STR_TOP1_DSTNC',
        'OFF_PRCHS_CNT_6M','PRCHS_CNT_2M_CHG_SCT3',
        'OFF_PRCHS_CNT_4M_CHG', 'EVNT_PRF_UNITY'
         ]
    
    # Target = 2 고객 분리하기 - 최근 3개월 구매횟수 & 구매금액이 0인 고객 
    df_t2 = df[(df["PRCHS_AMT_RECENT_3M"] == '0') & (df["PRCHS_CNT_RECENT_3M"] == '0')]
    
    # Target = 2 고객 정보 저장
    retention_target2_customer = df_t2[['INTG_CUST_NO','CUST_ANAL_GRP']]
    
    # Target = 2 Result Table 정보 추가
    retention_target2_customer['ANL_DT'] = 'target_date'
    retention_target2_customer['TARGET_CLASS'] = '2'
    retention_target2_customer['PREDICT_PROB'] = 2
    
    # 우수&일반고객 DF 생성
    df_vn = df[(df["PRCHS_AMT_RECENT_3M"] == '1') | (df["PRCHS_CNT_RECENT_3M"] == '1')]
    
    # 우수고객 DF 생성
    retention_vip = df_vn[(df_vn['CUST_ANAL_GRP'] == 'P1') | (df_vn['CUST_ANAL_GRP'] =='P2')]
    retention_vip = retention_vip[vip_col] 
    
    # 일반고객 DF 생성
    retention_normal = df_vn[(df_vn['CUST_ANAL_GRP'] == 'G1') | (df_vn['CUST_ANAL_GRP'] =='G2')]
    retention_normal = retention_normal[normal_col]
    
    return retention_vip, retention_normal, retention_target2_customer


def null_fill(retention_vip, retention_normal):
    
    vip_zero_cols = [
        'APT_YN_H','AGE_GRP_03',
        'PRCHS_AMT_2M_CHG','PRCHS_AMT_3M_CHG',
        'PRCHS_CNT_2M_CHG','PRCHS_CNT_4M_CHG',
        'PRCHS_CNT_1M','PRCHS_CNT_2M',
        'PRCHS_CNT_3M','CLDR_SNSTIVE_UNITY',
        'ON_PRCHS_CNT_6M','OFF_PRCHS_CNT_6M',
        'TOT_PNT','OFF_PRCHS_AMT_2M_CHG',
        'OFF_PRCHS_AMT_4M_CHG','RFMP_GRADE_2M_CHG'
         ]

    retention_vip[vip_zero_cols] = retention_vip[vip_zero_cols].fillna(0)
    retention_vip['PRCHS_CYCLE_VAR'] = retention_vip['PRCHS_CYCLE_VAR'].fillna(10)
    retention_vip['MAIN_PRCHS_STR_TOP1_DSTNC'] = retention_vip['MAIN_PRCHS_STR_TOP1_DSTNC'].fillna(1688)  
    retention_vip['PRCHS_CYCLE'] = retention_vip['PRCHS_CYCLE'].fillna(183)
    retention_vip['PRCHS_CYCLE_2M_DIFF'] = retention_vip['PRCHS_CYCLE_2M_DIFF'].fillna(retention_vip['PRCHS_CYCLE'])
    
    normal_zero_cols = [
        'RFMP_GRADE_2M_CHG',
        'PRCHS_AMT_1M','PRCHS_AMT_2M',
        'PRCHS_CNT_1M','PRCHS_CNT_2M',
        'PRCHS_CNT_3M','CLDR_SNSTIVE_UNITY',
        'OFF_PRCHS_CNT_6M','PRCHS_CNT_2M_CHG_SCT3',
        'OFF_PRCHS_CNT_4M_CHG','EVNT_PRF_UNITY'
         ]

    retention_normal[normal_zero_cols] = retention_normal[normal_zero_cols].fillna(0)
    retention_normal['PRCHS_CYCLE'] = retention_normal['PRCHS_CYCLE'].fillna(183)
    retention_normal['MAIN_PRCHS_STR_TOP1_DSTNC'] = retention_normal['MAIN_PRCHS_STR_TOP1_DSTNC'].fillna(3924)  
    retention_normal['PRCHS_AMT_VAR_IDEX'] = retention_normal['PRCHS_AMT_VAR_IDEX'].fillna(5) 
    retention_normal[['PRCHS_CYCLE_VAR','PRCHS_L2_CNT_VAR']] = retention_normal[['PRCHS_CYCLE_VAR','PRCHS_L2_CNT_VAR']].fillna(10)
    
    return retention_vip, retention_normal


def final_preprocessing(retention_vip, retention_normal):
    
    # 우수와 일반고객의 고객번호 & 고객등급 저장
    vip_cust_info = retention_vip[['INTG_CUST_NO','CUST_ANAL_GRP']]
    normal_cust_info = retention_normal[['INTG_CUST_NO','CUST_ANAL_GRP']]
    
    # 실제 예측에 사용하는 DF 생성
    retention_vip.drop(['INTG_CUST_NO','CUST_ANAL_GRP'],axis=1,inplace=True)
    retention_normal.drop(['INTG_CUST_NO','CUST_ANAL_GRP'],axis=1,inplace=True)
      
    return retention_vip, retention_normal, vip_cust_info, normal_cust_info

def load_model(DIR,MODEL_NAME):
    model_dir  = DIR+MODEL_NAME
    load_model = joblib.load(model_dir)
    return load_model


def retention_predict(customer_type, model_df, cust_info, model_dir , model_name):
    
    if customer_type == 'vip':
        
        vip_model= load_model(model_dir, model_name)
        pred_y_vip = (vip_model.predict_proba(model_df)[:,1]>= float(P_THRESHOLD)).astype(int)
        pred_prob_y_vip  = vip_model.predict_proba(model_df)

        # 예측 결과 DF 생성
        result_df = pd.DataFrame({'ANL_DT':'targe_date', 'INTG_CUST_NO':list(cust_info['INTG_CUST_NO'].values),
                                  'CUST_GRADE':list(cust_info['CUST_ANAL_GRP'].values), 
                                  'PREDICT_PROB':list(pred_prob_y_vip[:,1].round(2)), 
                                  'TARGET_CLASS':list(pred_y_vip)})
        result_df['TARGET_CLASS'] = result_df['TARGET_CLASS'].astype('str')
        
    elif customer_type == 'normal':
        
        normal_model = load_model(model_dir, model_name)
        pred_y_normal = (normal_model.predict_proba(model_df)[:,1]>= float(G_THRESHOLD)).astype(int)
        pred_prob_y_normal = normal_model.predict_proba(model_df)
        
        # 예측 결과 DF 생성
        result_df = pd.DataFrame({'ANL_DT':'targe_date', 'INTG_CUST_NO':list(cust_info['INTG_CUST_NO'].values),
                                  'CUST_GRADE':list(cust_info['CUST_ANAL_GRP'].values), 
                                  'PREDICT_PROB':list(pred_prob_y_normal[:,1].round(2)), 
                                  'TARGET_CLASS':list(pred_y_normal)})
        result_df['TARGET_CLASS'] = result_df['TARGET_CLASS'].astype('str')
        
    else:
        print('Prediction Error')
    
    return result_df

#------------------------------------------------------
# ■ Predict Pipeline
#------------------------------------------------------

try:
    with open(f'{HOME_DIR}/logs/mdap_model/{model_name}_SUCCESS_{today_date}.log', "a") as file:
        file.write('====================================================================================================\n')
        file.write(f'Log Type   : [ Success ]\n')
        file.write(f'Program ID : [ {module_name} ]\n')
        file.write(f'Model ID   : [ {model_id} ]\n')
        file.write(f'Start Time : [ {start_time} ]\n')
        file.write(f'Parameter  : [ {target_date} ]\n')
        file.write('====================================================================================================\n')
        a = '**********    Retention Python Program Start    **********'
        file.write(a.center(100, ' '))
        file.write('\n====================================================================================================\n')
        file.write('+---------+---------+---------+---------+---------+---------+---------+---------+---------+---------+\n')
        file.close()
    
    ## Step1 - Load Data 
    logger_success.error('*** (Step1) - Load Data Start')
    cl = dm.data_management("RETENTION", target_date)
    data = cl.data_load()
    
    ## Step 2 - Preprocess Loaded Data
    logger_success.error('*** (Step2) - Preprocessing Loaded Data Start')
    # 1) Lowercase to Uppercase
    new_columns = []
    for col in list(data.columns):
        new_columns.append(col.upper())
        
    data.columns = new_columns
    
    # 2) Change Data type 
    for col in data.columns:
        if col not in ['ANL_DT','INTG_CUST_NO','CUST_ANAL_GRP','PRCHS_AMT_RECENT_3M','PRCHS_CNT_RECENT_3M','AGE_GRP_03', 'APT_YN_H']:
            data[col] = data[col].astype('float')
        elif col in ['AGE_GRP_03', 'APT_YN_H']:
            data[col] = data[col].astype('int')
      
    ## Step 3 - Preprocessing for Prediction
    logger_success.error('*** (Step3) - Preprocessing for Prediction Start')
    # 1) 우수일반 고객 나누기
    retention_vip, retention_normal, retention_target2_customer = split_vip_normal(data)
    
    # 2) 결측치 처리
    retention_vip, retention_normal = null_fill(retention_vip, retention_normal)
    
    # 3) 최종 데이터 전처리
    retention_vip, retention_normal, vip_cust_info, normal_cust_info = final_preprocessing(retention_vip, retention_normal)   
    
    ## Step 4 - Predict 
    logger_success.error('*** (Step4) - Model Predict Start')
    # 1) 우수고객 예측
    result_df_vip = retention_predict('vip', retention_vip, vip_cust_info, MODEL_DIR, P_MODEL_NAME)
    
    # 2) 일반고객 예측
    result_df_normal = retention_predict('normal', retention_normal, normal_cust_info, MODEL_DIR, G_MODEL_NAME)

    ## Step 5 - Retention Result Table 생성
    logger_success.error('*** (Step5) - Save Retention Result Table Start')
    
    # 1) 우수+일반고객 Result Table 병합
    result_table = pd.concat([result_df_vip,result_df_normal],axis=0)
    
    # 2) Target = 2 고객 Result Table 변경
    retention_target2_customer = retention_target2_customer.rename(columns={'CUST_ANAL_GRP':'CUST_GRADE'})
    retention_target2_customer = retention_target2_customer[['ANL_DT','INTG_CUST_NO','CUST_GRADE','PREDICT_PROB','TARGET_CLASS']]
    
    # 3) 우수&일반고객 + Target = 2 고객 Result Table 병합
    result_table_final = pd.concat([result_table,retention_target2_customer],axis=0)
    result_table_final.loc[:,'ANL_DT'] = datetime.datetime.strptime(target_date, '%Y%m%d').strftime('%Y-%m-%d')
    
    ## Step 6 - Save Result Files & Remove Data
    logger_success.error('*** (Step6) - Save Result Files Start')
    output_file = '/analytics/mdap/src/data/output/F_ANL_RETENTION_PRED_RESULT_' + target_date
    
    if os.path.isfile(output_file+'.csv'):
        os.remove(output_file+'.csv')

    result_table_final.to_csv(output_file+'.csv', index=False)
    
    if os.path.isfile(output_file+'.chk'):
        os.remove(output_file+'.chk')
    
    file = output_file+'.chk'
    open(file, mode='w').close()
    
    cl.move_data()
    cl.remove_data()
    
    end_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with open(f'{HOME_DIR}/logs/mdap_model/{model_name}_SUCCESS_{today_date}.log', "a") as file:
        file.write('+---------+---------+---------+---------+---------+---------+---------+---------+---------+---------+\n')
        file.write('====================================================================================================\n')
        file.write(f'End Time : [ {end_time} ]\n')
        a = '**********    Retention Python Program End    **********'
        file.write(a.center(100, ' '))
        file.write('\n====================================================================================================\n')
        file.close()
    
except Exception as e : 
    logger_fail     = logging.getLogger('fail_log')
    fh_fail = logging.FileHandler(f'{HOME_DIR}/logs/mdap_model/{model_name}_FAIL_{today_date}.log')
    formatter_fail = logging.Formatter(f'[ %(asctime)s ][ LineNo. : %(message)s')
    fh_fail.setFormatter(formatter_fail)
    logger_fail.addHandler(fh_fail)    
    with open(f'{HOME_DIR}/logs/mdap_model/{model_name}_FAIL_{today_date}.log', "a") as file:
        file.write('====================================================================================================\n')
        file.write(f'Log Type   : [ Error ]\n')
        file.write(f'Program ID : [ {module_name} ]\n')
        file.write(f'Model ID   : [ {model_id} ]\n')
        file.write(f'Start Time : [ {start_time} ]\n')
        file.write(f'Parameter  : [ {target_date} ]\n')
        file.write('====================================================================================================\n')
        a = '**********    Retention Python Program Error    **********'
        file.write(a.center(100, ' '))
        file.write('\n====================================================================================================\n')
        file.write('+---------+---------+---------+---------+---------+---------+---------+---------+---------+---------+\n')
        file.close()
        
    _, _, exc_traceback = sys.exc_info()
    logger_fail.error(f'{exc_traceback.tb_lineno} ] ※ Error : {e}')  
    
    end_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with open(f'{HOME_DIR}/logs/mdap_model/{model_name}_FAIL_{today_date}.log', "a") as file:
        file.write('+---------+---------+---------+---------+---------+---------+---------+---------+---------+---------+\n')
        file.write('====================================================================================================\n')
        file.write('End Time : [ {end_time} ]\n')
        a = '**********    Retention Python Program Error    **********'
        file.write(a.center(100, ' '))
        file.write('\n====================================================================================================\n')
        file.close() 
