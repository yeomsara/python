import pandas_redshift as pr
import psycopg2
import pandas as pd
from IPython.display import display
import configparser
conf_dir = '/analytics/src/conf/config.ini'
cfg = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
cfg.read(conf_dir)

#---------------------------------------------------------
# ■ setting configuration (db_connectionm, load_model)
#---------------------------------------------------------
global HOST,PORT,DB_ID,DB_PW,MODEL_DIR,MODEL_NAME
DBNAME       = cfg['dbconnect']['dbname']
HOST         = cfg['dbconnect']['host']
PORT         = int(cfg['dbconnect']['port'])
USER_ID      = cfg['dbconnect']['user_id']
PASSWORD     =  cfg['dbconnect']['password']
AWS_ACCESS_KEY_ID     = cfg['dbconnect']['aws_access_key_id']
AWS_SECRET_ACCESS_KEY = cfg['dbconnect']['aws_secret_access_key']
AWS_DEFAULT_REGION    = cfg['dbconnect']['region']
BUCKET_NAME           = cfg['dbconnect']['bucket']

def query_request(query):
    connection_info = "dbname='{}' host='{}' port={} user='{}' password='{}'".format(DBNAME, HOST, PORT, USER_ID, PASSWORD)
    connection = psycopg2.connect(connection_info)
    df = pd.read_sql(query, connection)
    df.columns = [x.upper() for x in df.columns]
    connection.close()
    return df

# create / drop / delete / update 
def cud_request(query):
    pr.connect_to_redshift(dbname =DBNAME,
                        host = HOST,
                        port = PORT,
                        user = USER_ID,
                        password = PASSWORD)

    pr.connect_to_s3(aws_access_key_id = AWS_ACCESS_KEY_ID,
                aws_secret_access_key = AWS_SECRET_ACCESS_KEY,
                bucket = BUCKET_NAME)
    
    
    pr.exec_commit(query)
    pr.core.connect.commit()
    pr.core.connect.rollback()
    pr.close_up_shop()
    print(f'===== Query Execute success =====\n')

def replace_table(df,table_name,append_type):
    pr.connect_to_redshift(dbname =DBNAME,
                        host = HOST,
                        port = PORT,
                        user = USER_ID,
                        password = PASSWORD)

    pr.connect_to_s3(aws_access_key_id = AWS_ACCESS_KEY_ID,
                aws_secret_access_key = AWS_SECRET_ACCESS_KEY,
                bucket = BUCKET_NAME)
    
    pr.pandas_to_redshift(data_frame = df,
                        redshift_table_name = table_name,
                        append = append_type)
#     print(f'===== Query Execute success =====\n')
#     print(f'===== {table_name} / {append_type} =====\n')
