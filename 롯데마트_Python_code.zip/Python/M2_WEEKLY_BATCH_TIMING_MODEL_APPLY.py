
import sys 
import os
sys.path.append('/analytics/mdap/src/codeshare/')

import redshift_dbconnect as rs_connect

# ■ List of Package
## 함수 로딩  
import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')
import logging # This allows for seeing if the model converges. A log file is created.
import pickle,ast,joblib
import datetime
import configparser
from functools import wraps
import data_management  as dm
import argparse

# predict model
from lightgbm import LGBMClassifier
from xgboost  import XGBClassifier,XGBRFClassifier

#---------------------------------------------------------
# ■ setting configuration (db_connectionm, load_model)
#---------------------------------------------------------
import configparser
conf_dir = '/analytics/mdap/src/conf/config.ini'
cfg = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
cfg.read(conf_dir)

# Timing
global DATA_DIR, MODEL_DIR, MODEL_NAME, HOME_DIR, LOG_CONFIG
DATA_DIR = cfg['Data']['DATA_DIR']
MODEL_DIR  = cfg['Timing']['MODEL_DIR']
MODEL_NAME = cfg['Timing']['MODEL_NAME']

HOME_DIR   = cfg['common']['home_dir']
LOG_CONFIG = cfg['common']['log_config']


#----------------------------------------------------------
# ■ List of definition
#----------------------------------------------------------

def load_model(DIR, MODEL_NAME):
    model_dir  = DIR+MODEL_NAME
    load_model = joblib.load(model_dir)
    return load_model

def save_model(clf,mdl_file_nm):
    DIR = MODEL_DIR
    model_name = mdl_file_nm
    model = joblib.dump(clf,open(DIR+model_name+".pkl",'wb'))
    model_dir = DIR+model_name
    print('%s 경로에 %s 모델 저장완료 '%(DIR,model_name+".pkl"))
    return model_name

def df_pre(df):
    #Column명 대문자 변환
    new_columns = []
    for i in list(df.columns):
        new_columns.append(i.upper())
    df.columns = new_columns

    float_cols = ['AGE'
    ,'PRCHS_CNT'
    ,'PRCHS_AMT'
    ,'PRCHS_PER_AVG_AMT'
    ,'RFMP_GRD'
    ,'RFMP_FREQUENCY'
    ,'RFMP_MONETARY'
    ,'PRCHS_CYCLE'
    ,'PRCHS_CYCLE_VAR'
    ,'PRCHS_CYCLE_IDEX'
    ,'PRCHS_AMT_VAR'
    ,'PRCHS_AMT_VAR_IDEX'
    ,'PRCHS_CYCLE_ARRVLRT'
    ,'PRCHS_PER_AVG_AMT_IDEX'
    ,'RFMP_SCT1'
    ,'RFMP_SCT3'
    ,'PRCHS_CYCLE_SCT1'
    ,'PRCHS_CYCLE_SCT2'
    ,'PRCHS_CYCLE_SCT3'
    ,'PRCHS_CYCLE_VAR_SCT3'
    ,'PRCHS_CYCLE_IDEX_SCT1'
    ,'PRCHS_CYCLE_IDEX_SCT3'
    ,'PRCHS_CYCLE_ARRVLRT_SCT1'
    ,'PRCHS_CYCLE_ARRVLRT_SCT2'
    ,'PRCHS_CYCLE_ARRVLRT_SCT3'
    ,'MAIN_PRCHS_ARRVLRT'
    ,'PREFER_PRCHS_ARRVLRT'
    ,'PRCHS_CYCLE_ARRVLRT_CNT_SCT3'
    ,'EC_ONLN_PRCHS_LAPSE'
    ,'MAIN_PRCHS_STR_TOP1_DSTNC'
    ,'WEND_PRCHS_IDEX'
    ,'CLDR_SNSTIVE_UNITY'
    ,'CLDR_SNSTIVE_NAT_HOLI'
    ,'CLDR_SNSTIVE_EVNT'
    ,'CLDR_SNSTIVE_MAY_EVNT'
    ,'CLDR_SNSTIVE_SEMSTR'
    ,'CLDR_SNSTIVE_EST']

    df[float_cols] = df[float_cols].astype(float)

    return df

def fill_na(df):
    col_fill_0 = ['RFMP_GRD'
                  ,'RFMP_FREQUENCY'
                  ,'RFMP_MONETARY'
                  ,'RFMP_SCT1'
                  ,'RFMP_SCT3'
                  ,'PRCHS_CNT'
                  ,'PRCHS_AMT'
                  ,'PRCHS_PER_AVG_AMT'
                  ,'PRCHS_CYCLE_ARRVLRT_CNT_SCT3']

    col_fill_210 = ['PRCHS_CYCLE'
                    ,'PRCHS_CYCLE_SCT1'
                    ,'PRCHS_CYCLE_SCT2'
                    ,'PRCHS_CYCLE_SCT3']

    col_fill_31 = ['PRCHS_CYCLE_ARRVLRT'      
                    ,'PRCHS_CYCLE_ARRVLRT_SCT1' 
                    ,'PRCHS_CYCLE_ARRVLRT_SCT2' 
                    ,'PRCHS_CYCLE_ARRVLRT_SCT3' 
                    ,'MAIN_PRCHS_ARRVLRT'       
                    ,'PREFER_PRCHS_ARRVLRT']

    col_fill_30 = ['PRCHS_PER_AVG_AMT_IDEX' 
                    ,'PRCHS_CYCLE_IDEX'       
                    ,'PRCHS_CYCLE_IDEX_SCT1'  
                    ,'PRCHS_CYCLE_IDEX_SCT3']

    col_fill_10 = ['PRCHS_CYCLE_VAR'     
                    ,'PRCHS_CYCLE_VAR_SCT3'
                    ,'PRCHS_AMT_VAR'       
                    ,'PRCHS_AMT_VAR_IDEX']

    df[col_fill_0]   = df[col_fill_0].fillna(0)
    df[col_fill_210] = df[col_fill_210].fillna(210)
    df[col_fill_31]  = df[col_fill_31].fillna(31)
    df[col_fill_30]  = df[col_fill_30].fillna(30)
    df[col_fill_10]  = df[col_fill_10].fillna(10)
    
    df['AGE'] = df['AGE'].fillna(999)
    df['MAIN_PRCHS_STR_TOP1_DSTNC'] = df['MAIN_PRCHS_STR_TOP1_DSTNC'].fillna(999999)
    df['EC_ONLN_PRCHS_LAPSE'] = df['EC_ONLN_PRCHS_LAPSE'].fillna(20800)
    return df

def df_predict(df, model):
    feature_col = model.feature_name_
    df_feature = df[feature_col]
    
    pred = model.predict(df_feature)
    y_pred_prob = model.predict_proba(df_feature)
    
    return pred, y_pred_prob

def make_output_df(df, pred, y_pred_prob):
    df_temp = df.copy()
    df_temp['PREDICT_CLASS'] = pred
    df_temp['C1_PREDICT_PROB'] = list(y_pred_prob[:,0])
    df_temp['C2_PREDICT_PROB'] = list(y_pred_prob[:,1])
    df_temp['C3_PREDICT_PROB'] = list(y_pred_prob[:,2])

    df_temp['C1_PREDICT_PROB'] = df_temp['C1_PREDICT_PROB'].map('{:,.2f}'.format).astype(float)
    df_temp['C2_PREDICT_PROB'] = df_temp['C2_PREDICT_PROB'].map('{:,.2f}'.format).astype(float)
    df_temp['C3_PREDICT_PROB'] = df_temp['C3_PREDICT_PROB'].map('{:,.2f}'.format).astype(float)
    df_temp['ANL_DT'] = datetime.datetime.strptime(target_date, '%Y%m%d').strftime('%Y-%m-%d')
    
    df_temp["INTG_CUST_NO"] = df_temp["INTG_CUST_NO"].astype('str').str.zfill(14)
    
    return df_temp

def get_event_class(x1, x2, x3):
    if max(x1, x2, x3) <= x1: 
        return 1
    elif max(x1, x2, x3) <= x2:
        return 2
    else: return 3
    
def make_event_class_df(df):
    target_date_c1 = (datetime.datetime.strptime(target_date, '%Y%m%d') + datetime.timedelta(days=7)).strftime('%Y-%m-%d') 
    target_date_c2 = (datetime.datetime.strptime(target_date, '%Y%m%d') + datetime.timedelta(days=21)).strftime('%Y-%m-%d')
    
    #달력행사 마스터 
    sql_cldr = '''
        select *
        from lmdapt2_db.ET_CLDR_EVNT_MST
         '''

    df_cldr = rs_connect.query_request(sql_cldr)

    df_cldr["STDRD_DATE"] = df_cldr.apply(
        lambda x: pd.date_range(x["ST_DATE"], x["END_DATE"]), axis=1
    )

    df_cldr_final = (
        df_cldr.explode("STDRD_DATE", ignore_index = True)
        .drop(columns=["ST_DATE", "END_DATE"])
    )
    
    # 공휴일 마스터

    sql_holiday = '''
        SELECT DISTINCT STDRD_DATE,HOLI_FG_CD
          FROM LMDAPT2_DB.PD_STR_CALND
         WHERE HOLI_FG_CD = 'Y'  
    '''
    df_holiday = rs_connect.query_request(sql_holiday)
    df_holiday['STDRD_DATE'] = df_holiday['STDRD_DATE'].astype('datetime64[ns]')
    
    df_cal_post = df[['INTG_CUST_NO','WEND_PRCHS_IDEX', 
       'CLDR_SNSTIVE_NAT_HOLI', 'CLDR_SNSTIVE_EVNT', 'CLDR_SNSTIVE_MAY_EVNT',
       'CLDR_SNSTIVE_SEMSTR', 'CLDR_SNSTIVE_EST']]
    
    #C1 & C2 행사 수 COUNT
    df_cal_post['HOLIDAY_C1'] = len(df_holiday[(df_holiday['STDRD_DATE'] >= target_date)    & (df_holiday['STDRD_DATE'] < target_date_c1)])
    df_cal_post['HOLIDAY_C2'] = len(df_holiday[(df_holiday['STDRD_DATE'] >= target_date_c1) & (df_holiday['STDRD_DATE'] < target_date_c2)])

    df_cal_post['CLDR_SNSTIVE_NAT_HOLI_C1'] = len(df_cldr_final[(df_cldr_final['CLDR_TYPE_CD'] == 'NAT') & (df_cldr_final['STDRD_DATE'] >= target_date)    & (df_cldr_final['STDRD_DATE'] < target_date_c1)]['STDRD_DATE'].unique())
    df_cal_post['CLDR_SNSTIVE_NAT_HOLI_C2'] = len(df_cldr_final[(df_cldr_final['CLDR_TYPE_CD'] == 'NAT') & (df_cldr_final['STDRD_DATE'] >= target_date_c1) & (df_cldr_final['STDRD_DATE'] < target_date_c2)]['STDRD_DATE'].unique())

    df_cal_post['CLDR_SNSTIVE_EVNT_C1'] = len(df_cldr_final[(df_cldr_final['CLDR_TYPE_CD'] == 'DAY') & (df_cldr_final['STDRD_DATE'] >= target_date)    & (df_cldr_final['STDRD_DATE'] < target_date_c1)]['STDRD_DATE'].unique())
    df_cal_post['CLDR_SNSTIVE_EVNT_C2'] = len(df_cldr_final[(df_cldr_final['CLDR_TYPE_CD'] == 'DAY') & (df_cldr_final['STDRD_DATE'] >= target_date_c1) & (df_cldr_final['STDRD_DATE'] < target_date_c2)]['STDRD_DATE'].unique())

    df_cal_post['CLDR_SNSTIVE_MAY_EVNT_C1'] = len(df_cldr_final[(df_cldr_final['CLDR_TYPE_CD'] == 'FAM') & (df_cldr_final['STDRD_DATE'] >= target_date)    & (df_cldr_final['STDRD_DATE'] < target_date_c1)]['STDRD_DATE'].unique())
    df_cal_post['CLDR_SNSTIVE_MAY_EVNT_C2'] = len(df_cldr_final[(df_cldr_final['CLDR_TYPE_CD'] == 'FAM') & (df_cldr_final['STDRD_DATE'] >= target_date_c1) & (df_cldr_final['STDRD_DATE'] < target_date_c2)]['STDRD_DATE'].unique())

    df_cal_post['CLDR_SNSTIVE_SEMSTR_C1'] = len(df_cldr_final[(df_cldr_final['CLDR_TYPE_CD'] == 'SCH') & (df_cldr_final['STDRD_DATE'] >= target_date)    & (df_cldr_final['STDRD_DATE'] < target_date_c1)]['STDRD_DATE'].unique())
    df_cal_post['CLDR_SNSTIVE_SEMSTR_C2'] = len(df_cldr_final[(df_cldr_final['CLDR_TYPE_CD'] == 'SCH') & (df_cldr_final['STDRD_DATE'] >= target_date_c1) & (df_cldr_final['STDRD_DATE'] < target_date_c2)]['STDRD_DATE'].unique())

    df_cal_post['CLDR_SNSTIVE_EST_C1'] = len(df_cldr_final[(df_cldr_final['CLDR_TYPE_CD'] == 'EST') & (df_cldr_final['STDRD_DATE'] >= target_date)    & (df_cldr_final['STDRD_DATE'] < target_date_c1)]['STDRD_DATE'].unique())
    df_cal_post['CLDR_SNSTIVE_EST_C2'] = len(df_cldr_final[(df_cldr_final['CLDR_TYPE_CD'] == 'EST') & (df_cldr_final['STDRD_DATE'] >= target_date_c1) & (df_cldr_final['STDRD_DATE'] < target_date_c2)]['STDRD_DATE'].unique())
    
    #행사선호도 확률가중치
    df_cal_post['HOLIDAY_C1_PROB'] = df_cal_post['WEND_PRCHS_IDEX'] * df_cal_post['HOLIDAY_C1']
    df_cal_post['HOLIDAY_C2_PROB'] = df_cal_post['WEND_PRCHS_IDEX'] * df_cal_post['HOLIDAY_C2']

    df_cal_post['CLDR_SNSTIVE_NAT_HOLI_C1_PROB'] = df_cal_post['CLDR_SNSTIVE_NAT_HOLI'] * df_cal_post['CLDR_SNSTIVE_NAT_HOLI_C1']
    df_cal_post['CLDR_SNSTIVE_NAT_HOLI_C2_PROB'] = df_cal_post['CLDR_SNSTIVE_NAT_HOLI'] * df_cal_post['CLDR_SNSTIVE_NAT_HOLI_C2']

    df_cal_post['CLDR_SNSTIVE_EVNT_C1_PROB'] = df_cal_post['CLDR_SNSTIVE_EVNT'] * df_cal_post['CLDR_SNSTIVE_EVNT_C1']
    df_cal_post['CLDR_SNSTIVE_EVNT_C2_PROB'] = df_cal_post['CLDR_SNSTIVE_EVNT'] * df_cal_post['CLDR_SNSTIVE_EVNT_C2']

    df_cal_post['CLDR_SNSTIVE_MAY_EVNT_C1_PROB'] = df_cal_post['CLDR_SNSTIVE_MAY_EVNT'] * df_cal_post['CLDR_SNSTIVE_MAY_EVNT_C1']
    df_cal_post['CLDR_SNSTIVE_MAY_EVNT_C2_PROB'] = df_cal_post['CLDR_SNSTIVE_MAY_EVNT'] * df_cal_post['CLDR_SNSTIVE_MAY_EVNT_C2']

    df_cal_post['CLDR_SNSTIVE_SEMSTR_C1_PROB'] = df_cal_post['CLDR_SNSTIVE_SEMSTR'] * df_cal_post['CLDR_SNSTIVE_SEMSTR_C1']
    df_cal_post['CLDR_SNSTIVE_SEMSTR_C2_PROB'] = df_cal_post['CLDR_SNSTIVE_SEMSTR'] * df_cal_post['CLDR_SNSTIVE_SEMSTR_C2']

    df_cal_post['CLDR_SNSTIVE_EST_C1_PROB'] = df_cal_post['CLDR_SNSTIVE_EST'] * df_cal_post['CLDR_SNSTIVE_EST_C1']
    df_cal_post['CLDR_SNSTIVE_EST_C2_PROB'] = df_cal_post['CLDR_SNSTIVE_EST'] * df_cal_post['CLDR_SNSTIVE_EST_C2']
    
    HOLIDAY_C1_PROB_MAX               = float(df_cal_post['HOLIDAY_C1_PROB'].max())
    HOLIDAY_C2_PROB_MAX               = float(df_cal_post['HOLIDAY_C2_PROB'].max())

    CLDR_SNSTIVE_NAT_HOLI_C1_PROB_MAX = float(df_cal_post['CLDR_SNSTIVE_NAT_HOLI_C1_PROB'].max())
    CLDR_SNSTIVE_NAT_HOLI_C2_PROB_MAX = float(df_cal_post['CLDR_SNSTIVE_NAT_HOLI_C2_PROB'].max())

    CLDR_SNSTIVE_EVNT_C1_PROB_MAX     = float(df_cal_post['CLDR_SNSTIVE_EVNT_C1_PROB'].max())
    CLDR_SNSTIVE_EVNT_C2_PROB_MAX     = float(df_cal_post['CLDR_SNSTIVE_EVNT_C2_PROB'].max())

    CLDR_SNSTIVE_MAY_EVNT_C1_PROB_MAX = float(df_cal_post['CLDR_SNSTIVE_MAY_EVNT_C1_PROB'].max())
    CLDR_SNSTIVE_MAY_EVNT_C2_PROB_MAX = float(df_cal_post['CLDR_SNSTIVE_MAY_EVNT_C2_PROB'].max())

    CLDR_SNSTIVE_SEMSTR_C1_PROB_MAX   = float(df_cal_post['CLDR_SNSTIVE_SEMSTR_C1_PROB'].max())
    CLDR_SNSTIVE_SEMSTR_C2_PROB_MAX   = float(df_cal_post['CLDR_SNSTIVE_SEMSTR_C2_PROB'].max())

    CLDR_SNSTIVE_EST_C1_PROB_MAX      = float(df_cal_post['CLDR_SNSTIVE_EST_C1_PROB'].max())
    CLDR_SNSTIVE_EST_C2_PROB_MAX      = float(df_cal_post['CLDR_SNSTIVE_EST_C2_PROB'].max())
    
    df_cal_post['HOLIDAY_C1_PROB_NEW']               = df_cal_post['HOLIDAY_C1_PROB'].apply(lambda x: 0 if HOLIDAY_C1_PROB_MAX==0 else x/(HOLIDAY_C1_PROB_MAX*2))
    df_cal_post['HOLIDAY_C2_PROB_NEW']               = df_cal_post['HOLIDAY_C2_PROB'].apply(lambda x: 0 if HOLIDAY_C2_PROB_MAX==0 else x/(HOLIDAY_C2_PROB_MAX*2))

    df_cal_post['CLDR_SNSTIVE_NAT_HOLI_C1_PROB_NEW'] = df_cal_post['CLDR_SNSTIVE_NAT_HOLI_C1_PROB'].apply(lambda x: 0 if CLDR_SNSTIVE_NAT_HOLI_C1_PROB_MAX==0 else x/(CLDR_SNSTIVE_NAT_HOLI_C1_PROB_MAX*2))
    df_cal_post['CLDR_SNSTIVE_NAT_HOLI_C2_PROB_NEW'] = df_cal_post['CLDR_SNSTIVE_NAT_HOLI_C2_PROB'].apply(lambda x: 0 if CLDR_SNSTIVE_NAT_HOLI_C2_PROB_MAX==0 else x/(CLDR_SNSTIVE_NAT_HOLI_C2_PROB_MAX*2))

    df_cal_post['CLDR_SNSTIVE_EVNT_C1_PROB_NEW']     = df_cal_post['CLDR_SNSTIVE_EVNT_C1_PROB'].apply(lambda x: 0 if CLDR_SNSTIVE_EVNT_C1_PROB_MAX==0 else x/(CLDR_SNSTIVE_EVNT_C1_PROB_MAX*2))
    df_cal_post['CLDR_SNSTIVE_EVNT_C2_PROB_NEW']     = df_cal_post['CLDR_SNSTIVE_EVNT_C2_PROB'].apply(lambda x: 0 if CLDR_SNSTIVE_EVNT_C2_PROB_MAX==0 else x/(CLDR_SNSTIVE_EVNT_C2_PROB_MAX*2))

    df_cal_post['CLDR_SNSTIVE_MAY_EVNT_C1_PROB_NEW'] = df_cal_post['CLDR_SNSTIVE_MAY_EVNT_C1_PROB'].apply(lambda x: 0 if CLDR_SNSTIVE_MAY_EVNT_C1_PROB_MAX==0 else x/(CLDR_SNSTIVE_MAY_EVNT_C1_PROB_MAX*2))
    df_cal_post['CLDR_SNSTIVE_MAY_EVNT_C2_PROB_NEW'] = df_cal_post['CLDR_SNSTIVE_MAY_EVNT_C2_PROB'].apply(lambda x: 0 if CLDR_SNSTIVE_MAY_EVNT_C2_PROB_MAX==0 else x/(CLDR_SNSTIVE_MAY_EVNT_C2_PROB_MAX*2))

    df_cal_post['CLDR_SNSTIVE_SEMSTR_C1_PROB_NEW']   = df_cal_post['CLDR_SNSTIVE_SEMSTR_C1_PROB'].apply(lambda x: 0 if CLDR_SNSTIVE_SEMSTR_C1_PROB_MAX==0 else x/(CLDR_SNSTIVE_SEMSTR_C1_PROB_MAX*2))
    df_cal_post['CLDR_SNSTIVE_SEMSTR_C2_PROB_NEW']   = df_cal_post['CLDR_SNSTIVE_SEMSTR_C2_PROB'].apply(lambda x: 0 if CLDR_SNSTIVE_SEMSTR_C2_PROB_MAX==0 else x/(CLDR_SNSTIVE_SEMSTR_C2_PROB_MAX*2))

    df_cal_post['CLDR_SNSTIVE_EST_C1_PROB_NEW']      = df_cal_post['CLDR_SNSTIVE_EST_C1_PROB'].apply(lambda x: 0 if CLDR_SNSTIVE_EST_C1_PROB_MAX==0 else x/(CLDR_SNSTIVE_EST_C1_PROB_MAX*2))
    df_cal_post['CLDR_SNSTIVE_EST_C2_PROB_NEW']      = df_cal_post['CLDR_SNSTIVE_EST_C2_PROB'].apply(lambda x: 0 if CLDR_SNSTIVE_EST_C2_PROB_MAX==0 else x/(CLDR_SNSTIVE_EST_C2_PROB_MAX*2))

    df_cal_post['C1_CLDR_PROB'] = df_cal_post[['HOLIDAY_C1_PROB_NEW'
    ,'CLDR_SNSTIVE_NAT_HOLI_C1_PROB_NEW'
    ,'CLDR_SNSTIVE_EVNT_C1_PROB_NEW'
    ,'CLDR_SNSTIVE_MAY_EVNT_C1_PROB_NEW'
    ,'CLDR_SNSTIVE_SEMSTR_C1_PROB_NEW'
    ,'CLDR_SNSTIVE_EST_C1_PROB_NEW']].max(axis=1)

    df_cal_post['C2_CLDR_PROB'] = df_cal_post[['HOLIDAY_C2_PROB_NEW'
    ,'CLDR_SNSTIVE_NAT_HOLI_C2_PROB_NEW'
    ,'CLDR_SNSTIVE_EVNT_C2_PROB_NEW'
    ,'CLDR_SNSTIVE_MAY_EVNT_C2_PROB_NEW'
    ,'CLDR_SNSTIVE_SEMSTR_C2_PROB_NEW'
    ,'CLDR_SNSTIVE_EST_C2_PROB_NEW']].max(axis=1)
    
    df_post_final = df_cal_post[['INTG_CUST_NO', 'C1_CLDR_PROB', 'C2_CLDR_PROB']]
    
    return df_post_final

def make_final_output(df, df_post_final):
    df_output = pd.merge(df, df_post_final, how='left', on='INTG_CUST_NO')
    
    df_output['C1_PREDICT_PROB_TEMP'] = df_output['C1_PREDICT_PROB'] + df_output['C1_CLDR_PROB']
    df_output['C2_PREDICT_PROB_TEMP'] = df_output['C2_PREDICT_PROB'] + df_output['C2_CLDR_PROB']
    
    df_output['EVENT_CLASS'] = df_output.apply(lambda x: get_event_class(x['C1_PREDICT_PROB_TEMP'], x['C2_PREDICT_PROB_TEMP'], x['C3_PREDICT_PROB']), axis=1)
    df_output['EVENT_CLASS'] = df_output['EVENT_CLASS'].astype('str')
    
    df_final = df_output[['ANL_DT', 'INTG_CUST_NO', 'PREDICT_CLASS', 'EVENT_CLASS', 'C1_PREDICT_PROB', 'C2_PREDICT_PROB', 'C3_PREDICT_PROB']].reset_index(drop=True)
    
    return df_final


#----------------------------------------------------------
# ■ logging
#----------------------------------------------------------
import logging
import logging.config
import traceback


today_date = datetime.datetime.now().strftime('%Y%m%d')
start_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
module_name = 'M2_WEEKLY_BATCH_TIMING_MODEL_APPLY.py'
model_name = 'M2_WEEKLY_BATCH_TIMING_MODEL_APPLY'
model_id = 'TIMING'

logger_success     = logging.getLogger('success_log')
fh_success = logging.FileHandler(f'{HOME_DIR}/logs/mdap_model/{model_name}_SUCCESS_{today_date}.log')
formatter_success = logging.Formatter(f'[ %(asctime)s ][ LineNo. : %(lineno)d ] %(message)s')
fh_success.setFormatter(formatter_success)
logger_success.addHandler(fh_success)


#----------------------------------------------------------
# ■ predict pipeline
#----------------------------------------------------------

parser = argparse.ArgumentParser(description = 'Timing System ')
parser.add_argument('--target_date', help = '분석 기준일')
args = parser.parse_args()
try : 
    target_date = args.target_date
except : 
    target_date = None


try:
    with open(f'{HOME_DIR}/logs/mdap_model/{model_name}_SUCCESS_{today_date}.log', "a") as file:
        file.write('====================================================================================================\n')
        file.write(f'Log Type   : [ Success ]\n')
        file.write(f'Program ID : [ {module_name} ]\n')
        file.write(f'Model ID   : [ {model_id} ]\n')
        file.write(f'Start Time : [ {start_time} ]\n')
        file.write(f'Parameter  : [ {target_date} ]\n')
        file.write('====================================================================================================\n')
        a = '**********    Timing Python Program Start    **********'
        file.write(a.center(100, ' '))
        file.write('\n====================================================================================================\n')
        file.write('+---------+---------+---------+---------+---------+---------+---------+---------+---------+---------+\n')
        file.close()
        
    #Step1 - Load Data 
    logger_success.error('*** (Step1) - Load Data Start')
    cl = dm.data_management("TIMING", target_date)
    test_set = cl.data_load()
 
    
    #Step2 - Data Preprocessing 
    logger_success.error('*** (Step2) - Data Preprocessing Start')
    test_set = df_pre(test_set)
    test_final = fill_na(test_set)
    

    #Step3 - Model Predict 
    logger_success.error('*** (Step3) - Model Predict Start')
    model = load_model(MODEL_DIR, MODEL_NAME)
    pred, y_pred_prob = df_predict(test_final, model)
    df_output_temp = make_output_df(test_set, pred, y_pred_prob)
    
    
    #Step4 - Get Event Class (CLDR_SNSTIVE)
    logger_success.error('*** (Step4) - Get Event Class Start')
    df_event = make_event_class_df(test_set)

    
    #Step5 - Result Table 
    logger_success.error('*** (Step5) - Result Table Start')
    df_final = make_final_output(df_output_temp, df_event)
    
    OUTPUT_DIR = '/analytics/mdap/src/data/output/F_ANL_TIMING_PRED_RESULT_'
    OUTPUT_FILE = OUTPUT_DIR + target_date + '.csv'
    CHECK_FILE = OUTPUT_DIR + target_date + '.chk'

    if os.path.isfile(OUTPUT_FILE):
        os.remove(OUTPUT_FILE)
    df_final.to_csv(OUTPUT_FILE, index=False)
    
    if os.path.isfile(CHECK_FILE):
        os.remove(CHECK_FILE)
    open(CHECK_FILE, mode='w').close()
    
    cl.move_data()
    cl.remove_data()
    
    end_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with open(f'{HOME_DIR}/logs/mdap_model/{model_name}_SUCCESS_{today_date}.log', "a") as file:
        file.write('+---------+---------+---------+---------+---------+---------+---------+---------+---------+---------+\n')
        file.write('====================================================================================================\n')
        file.write(f'End Time : [ {end_time} ]\n')
        a = '**********    Timing Python Program End    **********'
        file.write(a.center(100, ' '))
        file.write('\n====================================================================================================\n')
        file.close()
    
except Exception as e : 
    logger_fail     = logging.getLogger('fail_log')
    fh_fail = logging.FileHandler(f'{HOME_DIR}/logs/mdap_model/{model_name}_FAIL_{today_date}.log')
    formatter_fail = logging.Formatter(f'[ %(asctime)s ][ LineNo. : %(message)s')
    fh_fail.setFormatter(formatter_fail)
    logger_fail.addHandler(fh_fail)    
    with open(f'{HOME_DIR}/logs/mdap_model/{model_name}_FAIL_{today_date}.log', "a") as file:
        file.write('====================================================================================================\n')
        file.write(f'Log Type   : [ Error ]\n')
        file.write(f'Program ID : [ {module_name} ]\n')
        file.write(f'Model ID   : [ {model_id} ]\n')
        file.write(f'Start Time : [ {start_time} ]\n')
        file.write(f'Parameter  : [ {target_date} ]\n')
        file.write('====================================================================================================\n')
        a = '**********    Timing Python Program Error    **********'
        file.write(a.center(100, ' '))
        file.write('\n====================================================================================================\n')
        file.write('+---------+---------+---------+---------+---------+---------+---------+---------+---------+---------+\n')
        file.close()
        
    _, _, exc_traceback = sys.exc_info()
    logger_fail.error(f'{exc_traceback.tb_lineno} ] ※ Error : {e}')  
    
    end_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with open(f'{HOME_DIR}/logs/mdap_model/{model_name}_FAIL_{today_date}.log', "a") as file:
        file.write('+---------+---------+---------+---------+---------+---------+---------+---------+---------+---------+\n')
        file.write('====================================================================================================\n')
        file.write('End Time : [ {end_time} ]\n')
        a = '**********    Timing Python Program Error    **********'
        file.write(a.center(100, ' '))
        file.write('\n====================================================================================================\n')
        file.close()    
